This is the the item of every column.
Every item cotains two columns. First column is relative error, second is time.

"1.jacobi 2.super_jacobi_2 3. super_jacobi_3 4.gauss_seidel 5.jacobi_chebyshev 6.super_jacobi_chebyshev_2 7.super_jacobi_chebyshev_3 8.gauss_seidel_chebyshev 9.PCG" 